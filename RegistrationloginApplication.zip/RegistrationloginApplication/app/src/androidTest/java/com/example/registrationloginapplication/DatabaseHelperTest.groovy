package com.example.registrationloginapplication

class DatabaseHelperTest extends groovy.util.GroovyTestCase {
}
